package parcial1;
    
public interface Programable {
    public void programar();
}
