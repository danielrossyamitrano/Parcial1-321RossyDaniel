package parcial1;

abstract class Actividad implements Programable{
    protected String tipo;
    protected String entrenador;
    protected NivelIntensidad nivel;
    
    
    public Actividad(String tipo, String entrenador, NivelIntensidad nivel) {
        this.tipo = tipo;
        this.entrenador = entrenador;
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "tipo='" + tipo + '\'' +
               ", entrenador='" + entrenador + '\'' +
               ", nivel=" + nivel +
               '}';
        }
}
