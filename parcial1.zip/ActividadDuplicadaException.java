
package parcial1;

public class ActividadDuplicadaException extends Exception {
    
    
}
