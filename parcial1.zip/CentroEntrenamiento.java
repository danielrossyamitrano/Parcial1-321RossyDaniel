package parcial1;

import java.util.ArrayList;
import java.util.List;

public class CentroEntrenamiento {
    private String nombre;
    private List<Actividad> actividades;

    public CentroEntrenamiento(String nombre) {
        this.nombre = nombre;
        this.actividades = new ArrayList<>();
    }

    public void agregarActividad(Actividad actividad)
            throws ActividadDuplicadaException {

        for (Actividad a : actividades) {
            if (a.tipo.equals(actividad.tipo)) {
                throw new ActividadDuplicadaException();
            }
        }

        actividades.add(actividad);
    }

    public List<Actividad> obtenerActividades() {
        return actividades;
    }
    
    public ArrayList<Actividad> filtrarPorNivel(NivelIntensidad nivel) {
        ArrayList<Actividad> resultado = new ArrayList<>();

        for (Actividad actividad : this.actividades) {
            if (actividad.nivel == nivel) {
                resultado.add(actividad);
            }
        }

        return resultado;
    }
}
