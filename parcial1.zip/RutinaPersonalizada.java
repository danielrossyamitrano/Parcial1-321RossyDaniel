package parcial1;

public class RutinaPersonalizada extends Actividad{
    private int duracion;
    
    
    public RutinaPersonalizada(String tipo, String entrenador, NivelIntensidad nivel, int duracion){
            super(tipo, entrenador, nivel);
            this.duracion = duracion;
    }
    
    @Override
    public void programar() {
        System.out.println("Programando rutina de " + duracion + " minutos");
    }
    
    public String generarInforme() {
        StringBuilder sb = new StringBuilder();

        sb.append("Tipo: ").append(tipo).append("\n");
        sb.append("Entrenador: ").append(entrenador).append("\n");
        sb.append("Nivel: ").append(nivel).append("\n");

        return sb.toString();
    }
 
}