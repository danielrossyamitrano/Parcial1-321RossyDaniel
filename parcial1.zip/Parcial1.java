
package parcial1;
import java.util.List;

public class Parcial1 {

public static void main(String[] args) {
    CentroEntrenamiento centro = new CentroEntrenamiento("Alto Rendimiento Sur");
try {
    centro.agregarActividad(
    new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.ALTA, 25)
);
    centro.agregarActividad(
    new RutinaPersonalizada("Plan Fuerza Inicial", "Martin Diaz",NivelIntensidad.MEDIA, 8)
);
    centro.agregarActividad(
    new EvaluacionFisica("Evaluacion Ingreso", "Carla Suarez", NivelIntensidad.BAJA, 78)
);
    centro.agregarActividad(
    new RutinaPersonalizada("Plan Resistencia", "Laura Gomez",NivelIntensidad.ALTA, 6)
);
    centro.agregarActividad(
    new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.MEDIA, 20)
);
}
catch (ActividadDuplicadaException e) {
System.out.println("No se pudo agregar la actividad: " + e.getMessage());
}
System.out.println("Actividades registradas:");
mostrarActividades(centro.obtenerActividades());
System.out.println();
System.out.println("Actividades programables:");
programarActividades(centro.obtenerActividades());
System.out.println();
System.out.println("Informes generados:");
generarInformesDesdeMain(centro.obtenerActividades());
System.out.println();
System.out.println("Actividades de intensidad ALTA:");
mostrarActividades(centro.filtrarPorNivel(NivelIntensidad.ALTA));
}
    private static void mostrarActividades(List<Actividad> actividades) {
        for (Actividad actividad : actividades) {
            System.out.println(actividad);
        }   
}
    private static void programarActividades(List<Actividad> actividades) {
        for (Actividad actividad : actividades) {
            actividad.programar();

        }
    }
    private static void generarInformesDesdeMain(List<Actividad> actividades) {
        for (Actividad actividad : actividades) {
            System.out.println(actividad);

        }
    }
}
