package parcial1;

public class EvaluacionFisica extends Actividad{
    private int puntaje;
    
public EvaluacionFisica(String tipo, String entrenador, NivelIntensidad nivel, int puntaje){
    super(tipo, entrenador, nivel);
    this.puntaje = puntaje;
    
}
@Override
public void programar() {
   System.out.println("las Evaluacion Fisicas no son programables");
}
 
public String generarInforme() {
        StringBuilder sb = new StringBuilder();

        sb.append("Tipo: ").append(tipo).append("\n");
        sb.append("Entrenador: ").append(entrenador).append("\n");
        sb.append("Nivel: ").append(nivel).append("\n");

        return sb.toString();
    }
}
