package parcial1;

public enum NivelIntensidad {
ALTA,
MEDIA,
BAJA
}
