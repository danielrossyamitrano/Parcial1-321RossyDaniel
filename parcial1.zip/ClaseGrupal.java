package parcial1;

public class ClaseGrupal extends Actividad{
    private int cantMaxParticipantes;
    
    
    public ClaseGrupal(String tipo, String entrenador, NivelIntensidad nivel, int cantMaxParticipantes){
        super(tipo, entrenador, nivel);
        this.cantMaxParticipantes = cantMaxParticipantes;
    }
    
    @Override
    public void programar() {
        System.out.println(
            "Programando clase grupal de " + cantMaxParticipantes + " participantes");
    }
}


